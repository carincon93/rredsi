<tr>
<td class="header" style="background-color: #ececec">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<?php if(trim($slot) === config('app.name')): ?>
<img src="<?php echo e(url('/storage/images/notification-logo.png')); ?>" class="logo" alt="Ibis Logo">

<?php else: ?>
<?php echo e($slot); ?>

<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH /home/vagrant/Dev/rredsi/resources/views/vendor/mail/html/header.blade.php ENDPATH**/ ?>