<?php $__currentLoopData = $knowledgeAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $knowledgeArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div>
        <p class="p-2">Área de conocimiento: <?php echo e($knowledgeArea->name); ?></p>
        <p class="p-2 text-gray-400">Sub-áreas de concimiento:</p>
        <?php $__currentLoopData = $knowledgeArea->knowledgeSubareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $knowledgeSubarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button type="button" class="accordion focus:outline-none bg-white hover:bg-gray-200"><?php echo e($knowledgeSubarea->name); ?></button>
            <div class="panel p-4">
            <p class="p-2 text-gray-400">Disciplinas de la sub-área de concimiento:</p>
            <?php $__currentLoopData = $knowledgeSubarea->knowledgeSubareaDisciplines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $knowledgeSubareaDiscipline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mt-4 mb-4">
                    <input class="form-check-input" type="checkbox" name="knowledge_subarea_discipline_id[]" <?php if(is_array(old('knowledge_subarea_discipline_id')) && in_array($knowledgeSubareaDiscipline->id, old('knowledge_subarea_discipline_id'))): ?> checked <?php else: ?> <?php if($model): ?> <?php echo e($model->knowledgeSubareaDisciplines->pluck('id')->contains($knowledgeSubareaDiscipline->id) ? 'checked' : ''); ?> <?php endif; ?> <?php endif; ?> id="<?php echo e("knowledge-subarea-discipline-$knowledgeSubareaDiscipline->id"); ?>" value="<?php echo e($knowledgeSubareaDiscipline->id); ?>" />
                    <label label class="font-medium inline inline-flex text-gray-700 text-sm ml-1" for="<?php echo e("knowledge-subarea-discipline-$knowledgeSubareaDiscipline->id"); ?>"><?php echo e($knowledgeSubareaDiscipline->name); ?></label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.section-border','data' => []]); ?>
<?php $component->withName('jet-section-border'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if (! $__env->hasRenderedOnce('ae45ff3c-589c-483a-a05b-42b682d51624')): $__env->markAsRenderedOnce('ae45ff3c-589c-483a-a05b-42b682d51624'); ?>                    
    <?php $__env->startPush('scripts'); ?>
    <script>
        var acc = document.getElementsByClassName('accordion');
        var i;
        
        for (i = 0; i < acc.length; i++) {
            acc[i].addEventListener('click', function() {
            this.classList.toggle('active');
            var panel = this.nextElementSibling;
            if (panel.style.display === 'block') {
                panel.style.display = 'none';
            } else {
                panel.style.display = 'block';
            }
            });
        }
    </script>
    <?php $__env->stopPush(); ?>
<?php endif; ?><?php /**PATH /home/vagrant/Dev/rredsi/resources/views/components/drop-down-knowledge-subarea-discipline.blade.php ENDPATH**/ ?>