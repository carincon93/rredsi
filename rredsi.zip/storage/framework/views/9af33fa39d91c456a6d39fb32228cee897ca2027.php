<?php echo e($slot); ?>

<?php /**PATH /home/vagrant/Dev/rredsi/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>