

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col">
            <h3><?php echo e($educationalTool->name); ?></h3>
        </div>
        <div class="col-2 text-right">
            <a href="/app/educational-tools/edit/<?php echo e($educationalTool->id); ?>">Editar</a>
        </div>
    </div>
    <hr/>
    <div class="row mb-3">
        <div class="col">
            <h5>Cantidad</h5>
            <h6><?php echo e($educationalTool->qty); ?></h6>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col">
            <h5>Institucion educativa</h5>
            <h6><?php echo e($educationalTool->educational_environment->educational_institution->name); ?></h6>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col">
            <h5>Descripcion</h5>
            <h6><?php echo e($educationalTool->description); ?></h6>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col">
            <h5>¿Esta habilitado?</h5>
            <h6><?php echo e($educationalTool->is_enabled?'Si':'No'); ?></h6>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col">
            <h5>¿Esta disponible?</h5>
            <h6><?php echo e($educationalTool->is_available?'Si':'No'); ?></h6>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col">
            <h5>Ambiente</h5>
            <h6><?php echo e($educationalTool->educational_environment->name); ?></h6>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Dev/rredsi/resources/views/EducationalTools/show.blade.php ENDPATH**/ ?>