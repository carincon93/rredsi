 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-display text-white text-3xl leading-9 font-semibold sm:text-3xl sm:leading-9">
            <?php echo e(__('Knowledge subarea disciplines')); ?>

            <span class="sm:block text-purple-300">
                Show knowledge subarea info
            </span>
        </h2>
        <div>
            <a href="<?php echo e(route('knowledge-subareas.edit', $knowledgeSubarea->id)); ?>">
                <div class="w-full sm:w-auto items-center justify-center text-purple-900 group-hover:text-purple-500 font-medium leading-none bg-white rounded-lg shadow-sm group-hover:shadow-lg py-3 px-5 border border-transparent transform group-hover:-translate-y-0.5 transition-all duration-150">
                    <?php echo e(__('Edit knowledge subarea')); ?>

                </div>
            </a>
        </div>
     <?php $__env->endSlot(); ?>
    
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="flex flex-wrap" id="tabs-id">
                <div class="w-full">
                    <ul class="flex mb-0 list-none flex-wrap pt-3 pb-4 flex-row">
                        <li class="-mb-px mr-2 last:mr-0 flex-auto text-center">
                            <a class="text-xs font-bold uppercase px-5 py-3 shadow-lg rounded block leading-normal text-white bg-blue-900" onclick="changeActiveTab(event,'tab-profile')">
                                <?php echo e(__('Knowledge subarea')); ?>

                            </a>
                        </li>
                        <li class="-mb-px mr-2 last:mr-0 flex-auto text-center">
                            <a class="text-xs font-bold uppercase px-5 py-3 shadow-lg rounded block leading-normal text-blue-900 bg-white" onclick="changeActiveTab(event,'tab-settings')">
                                <?php echo e(__('Knowledge area')); ?>

                            </a>
                        </li>
                        <li class="-mb-px mr-2 last:mr-0 flex-auto text-center">
                            <a class="text-xs font-bold uppercase px-5 py-3 shadow-lg rounded block leading-normal text-blue-900 bg-white" onclick="changeActiveTab(event,'tab-options')">
                                <?php echo e(__('Knowledge subarea disciplines' )); ?>

                            </a>
                        </li>
                    </ul>
                    <div class="px-4 py-5 flex-auto">
                        <div class="tab-content tab-space">
                            
                            <div class="block" id="tab-profile">
                                
                                
                                <div class="max-w-7xl mx-auto py-10 sm:px-6 lg:px-8">
                                        <div class="md:grid md:grid-cols-2 md:gap-4">
                                            <div>
                                                <h3 class="text-lg font-medium text-gray-900">Información de la sub-área de conocimiento</h3>
                                            </div>
                                            <div>
                                                <div class="px-4 py-5 sm:p-6 bg-white shadow sm:rounded-lg">
                                                    <h3 class="text-lg font-medium text-gray-900"><?php echo e(__('Name')); ?></h3>
                                                    <div class="mt-3 max-w-xl text-sm text-gray-600">
                                                        <p>
                                                            <?php echo e($knowledgeSubarea->name); ?>

                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="hidden sm:block">
                                            <div class="py-8">
                                                <div class="border-t border-gray-200"></div>
                                            </div>
                                        </div>
                                </div>
                            </div>
                            <div class="hidden" id="tab-settings">
                                
                                <div class="max-w-7xl mx-auto py-10 sm:px-6 lg:px-8">
                                    <div class="md:grid md:grid-cols-2 md:gap-4">
                                        <div>
                                            <h3 class="text-lg font-medium text-gray-900">Información de la área de conocimiento</h3>
                                        </div>
                                        
                                        <div>
                                            <div class="px-4 py-5 sm:p-6 bg-white shadow sm:rounded-lg">
                                                <h3 class="text-lg font-medium text-gray-900"><?php echo e(__('Name')); ?></h3>
                                                <div class="mt-3 max-w-xl text-sm text-gray-600">
                                                    <p>
                                                        <?php echo e($knowledgeSubarea->knowledgeArea->name); ?>

                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="hidden sm:block">
                                        <div class="py-8">
                                            <div class="border-t border-gray-200"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="hidden" id="tab-options">
                                
                                <div class="max-w-7xl mx-auto py-10 sm:px-6 lg:px-8">
                                    <div class="md:grid md:grid-cols-2 md:gap-4">
                                        <div>
                                            <h3 class="text-lg font-medium text-gray-900">Información de disciplinas de sub-áreas de conocimiento</h3>
                                        </div>
                                        
                                        <div>
                                            <?php $__currentLoopData = $knowledgeSubarea->knowledgeSubareaDisciplines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $knowledgeSubareaDiscipline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="px-4 py-5 sm:p-6 bg-white shadow sm:rounded-lg">
                                                    <h3 class="text-lg font-medium text-gray-900"><?php echo e(__('Name')); ?></h3>
                                                    <div class="mt-3 max-w-xl text-sm text-gray-600">
                                                        <p>
                                                            <?php echo e($knowledgeSubareaDiscipline->name); ?>

                                                        </p>
                                                    </div>
                                                </div>
                                                
                                                <div class="hidden sm:block">
                                                    <div class="py-8">
                                                        <div class="border-t border-gray-200"></div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 



<?php /**PATH /home/vagrant/Dev/rredsi/resources/views/KnowledgeSubareas/show.blade.php ENDPATH**/ ?>