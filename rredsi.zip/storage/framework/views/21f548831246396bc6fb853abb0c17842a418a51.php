

<?php $__env->startSection('content'); ?>

<div className="container">
    <div className="card p-4 detail">
      <div className="card-header">
        <h4><?php echo e($researchTeam->name); ?></h4>
        <a href="/app/research-teams/edit/<?php echo e($researchTeam->id); ?>"">
          Editar
          </a>
      </div>

      <ul className="list-unstyled">
        <li className="media my-4">
          <img className="mr-3" src="images/shapes/circle.png" alt="circle" />
          <div className="media-body">
            <h5 className="mt-0 mb-1">Nombre del mentor</h5>
            <?php echo e($researchTeam->mentor_name); ?>

          </div>
        </li>
        <li className="media my-4">
          <img className="mr-3" src="images/shapes/circle.png" alt="circle" />
          <div className="media-body">
            <h5 className="mt-0 mb-1">Correo electrónico del mentor</h5>
            <?php echo e($researchTeam->mentor_email); ?>

          </div>
        </li>
        <li className="media my-4">
          <img className="mr-3" src="images/shapes/circle.png" alt="circle" />
          <div className="media-body">
            <h5 className="mt-0 mb-1">Número celular del mentor</h5>
            <?php echo e($researchTeam->mentor_cellphone); ?>

          </div>
        </li>
        <li className="media my-4">
          <img className="mr-3" src="images/shapes/circle.png" alt="circle" />
          <div className="media-body">
            <h5 className="mt-0 mb-1">Objetivo general</h5>
            <?php echo e($researchTeam->overall_objective); ?>

          </div>
        </li>
        <li className="media my-4">
          <img className="mr-3" src="images/shapes/circle.png" alt="circle" />
          <div className="media-body">
            <h5 className="mt-0 mb-1">Misión</h5>
            <?php echo e($researchTeam->mission); ?>

          </div>
        </li>
        <li className="media my-4">
          <img className="mr-3" src="images/shapes/circle.png" alt="circle" />
          <div className="media-body">
            <h5 className="mt-0 mb-1">Visión</h5>
            <?php echo e($researchTeam->vision); ?>

          </div>
        </li>
        <li className="media my-4">
          <img className="mr-3" src="images/shapes/circle.png" alt="circle" />
          <div className="media-body">
            <h5 className="mt-0 mb-1">Proyección regional</h5>
            <?php echo e($researchTeam->regional_projection); ?>

          </div>
        </li>
        <li className="media my-4">
          <img className="mr-3" src="images/shapes/circle.png" alt="circle" />
          <div className="media-body">
            <h5 className="mt-0 mb-1">Estrategia de producción de conocimiento</h5>
            <?php echo e($researchTeam->knowledge_production_strategy); ?>

          </div>
        </li>
        <li className="media my-4">
          <img className="mr-3" src="images/shapes/circle.png" alt="circle" />
          <div className="media-body">
            <h5 className="mt-0 mb-1">Temáticas de investigación</h5>
            <?php echo e($thematicResearch); ?>

          </div>
        </li>
        <li className="media my-4">
          <img className="mr-3" src="images/shapes/circle.png" alt="circle" />
          <div className="media-body">
            <h5 className="mt-0 mb-1">Áreas de conocimiento</h5>
            <ul>
                <?php $__empty_1 = true; $__currentLoopData = $researchTeam->knowledge_areas?; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $knowledge_area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li><?php echo e($knowledge_area->name); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li></li>
                <?php endif; ?>
            </ul>
          </div>
        </li>
        <li className="media my-4">
          <img className="mr-3" src="images/shapes/circle.png" alt="circle" />
          <div className="media-body">
            <h5 className="mt-0 mb-1">Líneas de investigación</h5>
            <ul>
                <?php $__empty_1 = true; $__currentLoopData = $researchTeam->research_lines?; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $researchLine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li ><?php echo e($researchLine->name); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li></li>
                <?php endif; ?>

            </ul>
          </div>
        </li>
        <li className="media my-4">
          <img className="mr-3" src="images/shapes/circle.png" alt="circle" />
          <div className="media-body">
            <h5 className="mt-0 mb-1">Administrador</h5>
            <?php echo e($researchTeam->administrator?->user->name); ?>

          </div>
        </li>
        <li className="media my-4">
          <img className="mr-3" src="images/shapes/circle.png" alt="circle" />
          <div className="media-body">
            <h5 className="mt-0 mb-1">Estudiante lider</h5>
            <?php echo e($researchTeam->student_leader === null? 'Aun no tiene':'Si tiene'); ?>

          </div>
        </li>
        <li className="media my-4">
          <img className="mr-3" src="images/shapes/circle.png" alt="circle" />
          <div className="media-body">
            <h5 className="mt-0 mb-1">Grupo de investigacion</h5>
            <?php echo e($researchTeam->research_group->name); ?>

          </div>
        </li>
      </ul>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Dev/rredsi/resources/views/ResearchTeams/show.blade.php ENDPATH**/ ?>