<?php echo e($slot); ?>

<?php /**PATH /home/vagrant/Dev/rredsi/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>