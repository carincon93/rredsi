<div class="mt-4">
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['for' => 'knowledge_area_id','value' => ''.e(__('Knowledge area')).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'knowledge_area_id','value' => ''.e(__('Knowledge area')).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <p class="mt-4"><?php echo e(__('Knowledge areas')); ?> </p>
    <select class="form-select rounded-md border-0 p-3.5 shadow-sm block mt-1 w-full" id="knowledge_area_id" name="knowledge_area_id" required onchange="SwitchknowledgeSubareasDisciplines.onChange(event)">
        <?php $__currentLoopData = $knowledgeAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $knowledgeArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($knowledgeArea->id); ?>" <?php echo e(old('knowledge_area_id') == $knowledgeArea->id || optional(optional(optional($academicProgram)->educationalInstitution)->node)->id == $knowledgeArea->id ? 'selected' : ''); ?>><?php echo e($knowledgeArea->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="ml-4">
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['for' => 'knowledge_subarea_id','value' => ''.e(__('Knowledge subareas')).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'knowledge_subarea_id','value' => ''.e(__('Knowledge subareas')).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <select class="mr-10 focus:outline-none form-select rounded-md border-0 p-3.5 shadow-sm block mt-1 w-full" disabled id="knowledge_subarea_id" name="knowledge_subarea_id" required onchange="SwitchknowledgeSubareasDisciplines.onChangeDisciplines(event)">
        <option value="">Seleccione una sub-área de conocimiento</option>
    </select>
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'knowledge_subarea_id','class' => 'mt-2']]); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'knowledge_subarea_id','class' => 'mt-2']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
</div>

<div class="mt-4" id="check">
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'knowledge_subarea_discipline_id','class' => 'mt-2']]); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'knowledge_subarea_discipline_id','class' => 'mt-2']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
</div>

<textarea id="subAreaDiciplineOldId" class="hidden"></textarea>

<?php if (! $__env->hasRenderedOnce('2ff72584-cce4-4afc-9207-43cc06592f8f')): $__env->markAsRenderedOnce('2ff72584-cce4-4afc-9207-43cc06592f8f'); ?>
    <?php $__env->startPush('scripts'); ?>
        <script>
            let knowledgeAreaIdOld  = null;
            let knowledgeSubareaIdOld  = null;

            let areaOldId = document.getElementById('areaOldId');
            areaOldId.innerHTML = '<?php echo e(old('knowledge_area_id')); ?>';

            if(areaOldId.value != null && areaOldId.value != 0 ){
                knowledgeAreaIdOld = areaOldId.value;
            }

            if(subAreaOldId.value != null && subAreaOldId.value != 0 ){
                knowledgeSubareaIdOld = subAreaOldId.value;
            }

            var SwitchknowledgeSubareasDisciplines = (function() {
                let knowledgeAreaId                           = null;

                getAllKnowledgeAreas = async (knowledgeAreaselected) => {
                const knowledgeAreasSelect                     = document.getElementById('knowledge_area_id');
                knowledgeAreasSelect.innerHTML = '<option value="">Seleccione un knowledge area</option>';

                try {
                        const uri       = `/api/knowledge-areas`;
                        const response  = await fetch(uri);
                        const result    = await response.json();

                        result.knowledgeAreas.map(function(knowledgeArea) {
                            knowledgeAreasSelect.removeAttribute('disabled','disabled');
                            let option = `<option  value="${knowledgeArea.id}">${knowledgeArea.name}</option>`;
                            knowledgeAreasSelect.innerHTML += option;
                        })

                        if (knowledgeAreaselected != 0) {
                            knowledgeAreasSelect.querySelector(`option[value="${knowledgeAreaselected}"]`).setAttribute('selected', 'selected');
                        }
                    } catch (error) {
                        console.log(error);
                    }
            }

                getAllKnowledgeSubareas  = async (knowledgeArea, knowledgeSubareaId) => {
                    const knowledgeSubareaIdSelect   = document.getElementById('knowledge_subarea_id');
                    knowledgeSubareaIdSelect.innerHTML = '<option value="">Seleccione un knowledge subarea</option>';

                    if (knowledgeArea != 0) {
                        try {
                            const uri       = `/api/knowledge-areas/${knowledgeArea}/knowledge-subareas`;
                            const response  = await fetch(uri);
                            const result    = await response.json();


                            result.KnowledgeSubareas.map(function(knowledgeSubarea) {
                                knowledgeSubareaIdSelect.removeAttribute('disabled');
                                let option = `<option value="${knowledgeSubarea.id}">${knowledgeSubarea.name}</option>`;
                                knowledgeSubareaIdSelect.innerHTML += option;
                            })

                            if (knowledgeSubareaId != 0) {
                                knowledgeSubareaIdSelect.querySelector(`option[value="${knowledgeSubareaId}"]`).setAttribute('selected', 'selected');
                            }
                        } catch (error) {
                            console.log(error);
                        }
                    }
                }

                getAllKnowledgeSubareaDisciplines  = async (knowledgeArea, knowledgeSubarea, knowledgeSubareaDisciplineId) => {
                    const knowledgeSubareaDisciplineidSelect   = document.getElementById('check');

                    if (knowledgeArea != 0 && knowledgeSubarea != 0 ) {
                        try {
                            const uri       = `/api/knowledge-areas/${knowledgeArea}/knowledge-subareas/${knowledgeSubarea}/knowledge-subarea-disciplines`;
                            const response  = await fetch(uri);
                            const result    = await response.json();

                            result.knowledgeSubareaDiscipline.map(function(knowledgeSubareaDiscipline) {
                                let check = ` <input class="form-check-input" type="checkbox" name="knowledge_subarea_discipline_id[]" id="Knowledge-subarea-discipline-${knowledgeSubareaDiscipline.id}" value="${knowledgeSubareaDiscipline.id } required"/>
                                <label   label class="font-medium inline inline-flex text-gray-700 text-sm ml-1" for="Knowledge-subarea-discipline-${knowledgeSubareaDiscipline.id}">${knowledgeSubareaDiscipline.name }</label>`;

                                knowledgeSubareaDisciplineidSelect.innerHTML += check;
                            })

                            // if (knowledgeSubareaDisciplineId != 0) {
                            //     knowledgeSubareaDisciplineidSelect.querySelector(`input [value="${knowledgeSubareaDisciplineId}"]`).setAttribute('checked', 'checked');
                            // }
                        } catch (error) {
                            console.log(error);
                        }
                    }
                }

                if (knowledgeAreaIdOld != null && knowledgeSubareaIdOld != null) {
                    getAllKnowledgeAreas(knowledgeAreaIdOld);
                    getAllKnowledgeSubareas(knowledgeAreaIdOld, knowledgeSubareaIdOld);
                    getAllKnowledgeSubareaDisciplines(knowledgeAreaIdOld, knowledgeSubareaIdOld);
                }

                return {
                    getAllKnowledgeAreas: function() {
                        getAllKnowledgeAreas();
                    },
                    onChange: function(e) {
                        knowledgeAreaId = e.target.value;
                        getAllKnowledgeSubareas (knowledgeAreaId, null);
                    },
                    onChangeDisciplines: function(e) {
                        knowledgeSubareaId = e.target.value;
                        if (knowledgeAreaIdOld != null && knowledgeAreaIdOld != 0) {
                            knowledgeareaId = knowledgeAreaIdOld;
                        } else {
                            knowledgeareaId = document.getElementById('knowledge_area_id').value;
                        }
                        getAllKnowledgeSubareaDisciplines(knowledgeareaId, knowledgeSubareaId, null);
                    },
                }
            })();

            SwitchknowledgeSubareasDisciplines.getAllKnowledgeAreas();

        </script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH /home/vagrant/Dev/rredsi/resources/views/components/drop-down-knowledge-subarea-dicipline.blade.php ENDPATH**/ ?>