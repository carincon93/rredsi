

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card p-4 detail">
      <div class="card-header">
          <h4><?php echo e($educationalInstitution->name); ?></h4>
          <a href="/app/educational-institutions/edit/<?php echo e($educationalInstitution->id); ?>">
            Editar
          </a>
      </div>
  <hr/>
      <ul class="list-unstyled">
        <li class="media">
          <img class="mr-3" src="" alt="circle" />
          <div class="media-body">
              <h5 class="mt-0 mb-1">Nit</h5>
              <?php echo e($educationalInstitution->nit); ?>

          </div>
        </li>
        <li class="media my-4">
          <img class="mr-3" src="" alt="circle" />
          <div class="media-body">
              <h5 class="mt-0 mb-1">Dirección</h5>
              <?php echo e($educationalInstitution->address); ?>

          </div>
        </li>
        <li class="media my-4">
          <img class="mr-3" src="" alt="circle" />
          <div class="media-body">
              <h5 class="mt-0 mb-1">Ciudad</h5>
              <?php echo e($educationalInstitution->city); ?>

          </div>
        </li>
        <li class="media my-4">
          <img class="mr-3" src="" alt="circle" />
          <div class="media-body">
              <h5 class="mt-0 mb-1">Telefono</h5>
              <?php echo e($educationalInstitution->phone_number); ?>

          </div>
        </li>
        <li class="media my-4">
          <img class="mr-3" src="" alt="circle" />
          <div class="media-body">
              <h5 class="mt-0 mb-1">Sitio web</h5>
              <?php echo e($educationalInstitution->website); ?>

          </div>
        </li>
        <li class="media my-4">
          <img class="mr-3" src="" alt="circle" />
          <div class="media-body">
              <h5 class="mt-0 mb-1">Administrador de la institución educativa</h5>
              <?php echo e($educationalInstitution->administrator?->user?->name); ?>

          </div>
        </li>
      </ul>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Dev/rredsi/resources/views/EducationalInstitutions/show.blade.php ENDPATH**/ ?>